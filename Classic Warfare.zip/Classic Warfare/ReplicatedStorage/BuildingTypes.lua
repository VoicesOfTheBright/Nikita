-- BuildingTypes.lua
local BuildingTypes = {}

-- ========== NOOBS ==========
BuildingTypes.NoobHut = {
    Name = "Noob Hut", Faction = "Noobs",
    Cost = { Gold = 300, Lumber = 100 },
    Health = 800, Size = Vector3.new(8, 6, 8),
    ModelName = "NoobHutModel", CanTrain = {},
}

BuildingTypes.NoobBarracks = {
    Name = "Noob Barracks", Faction = "Noobs",
    Cost = { Gold = 200, Lumber = 150 },
    Health = 600, Size = Vector3.new(6, 5, 6),
    ModelName = "NoobBarracksModel",
    CanTrain = { "NoobRecruit", "NoobKnight" },
}

BuildingTypes.NoobRange = {
    Name = "Noob Archery Range", Faction = "Noobs",
    Cost = { Gold = 180, Lumber = 130 },
    Health = 500, Size = Vector3.new(6, 5, 6),
    ModelName = "NoobRangeModel",
    CanTrain = { "NoobSlinger" },
}

BuildingTypes.NoobTower = {
    Name = "Noob Tower", Faction = "Noobs",
    Cost = { Gold = 150, Lumber = 120 },
    Health = 400, Size = Vector3.new(4, 8, 4),
    ModelName = "NoobTowerModel",
    AttackRange = 14, AttackDamage = 10,
}

BuildingTypes.NoobStable = {
    Name = "Noob Stable", Faction = "Noobs",
    Cost = { Gold = 250, Lumber = 180 },
    Health = 550, Size = Vector3.new(6, 5, 6),
    ModelName = "NoobStableModel",
    CanTrain = { "NoobBrute" },
}

-- ========== GUESTS ==========
BuildingTypes.GuestCamp = {
    Name = "Guest Camp", Faction = "Guests",
    Cost = { Gold = 300, Lumber = 100 },
    Health = 750, Size = Vector3.new(8, 6, 8),
    ModelName = "GuestCampModel", CanTrain = {},
}

BuildingTypes.GuestBarracks = {
    Name = "Guest Barracks", Faction = "Guests",
    Cost = { Gold = 210, Lumber = 150 },
    Health = 620, Size = Vector3.new(6, 5, 6),
    ModelName = "GuestBarracksModel",
    CanTrain = { "GuestRecruit", "GuestWarden" },
}

BuildingTypes.GuestWatchtower = {
    Name = "Guest Watchtower", Faction = "Guests",
    Cost = { Gold = 160, Lumber = 130 },
    Health = 430, Size = Vector3.new(4, 9, 4),
    ModelName = "GuestWatchtowerModel",
    AttackRange = 16, AttackDamage = 12,
}

BuildingTypes.GuestForge = {
    Name = "Guest Forge", Faction = "Guests",
    Cost = { Gold = 240, Lumber = 160 },
    Health = 560, Size = Vector3.new(6, 5, 6),
    ModelName = "GuestForgeModel",
    CanTrain = { "GuestHunter" },
}

BuildingTypes.GuestStable = {
    Name = "Guest Stable", Faction = "Guests",
    Cost = { Gold = 260, Lumber = 190 },
    Health = 570, Size = Vector3.new(6, 5, 6),
    ModelName = "GuestStableModel",
    CanTrain = { "GuestOverseer" },
}

function BuildingTypes.Get(name)
    return BuildingTypes[name]
end

function BuildingTypes.GetForFaction(factionName)
    local list = {}
    for key, data in pairs(BuildingTypes) do
        if type(data) == "table" and data.Faction == factionName then
            list[key] = data
        end
    end
    return list
end

return BuildingTypes