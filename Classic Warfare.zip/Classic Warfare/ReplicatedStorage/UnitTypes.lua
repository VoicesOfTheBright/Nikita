-- UnitTypes.lua
local UnitTypes = {}

-- ========== NOOBS ==========
UnitTypes.NoobRecruit = {
    Name = "Noob Recruit", Faction = "Noobs",
    Cost = { Gold = 50, Lumber = 0 },
    Health = 100, Damage = 12, Range = 2, Speed = 8, BuildTime = 3,
    ModelName = "NoobRecruitModel",
}

UnitTypes.NoobSlinger = {
    Name = "Noob Slinger", Faction = "Noobs",
    Cost = { Gold = 75, Lumber = 25 },
    Health = 70, Damage = 18, Range = 12, Speed = 7, BuildTime = 4,
    ModelName = "NoobSlingerModel",
}

UnitTypes.NoobKnight = {
    Name = "Noob Knight", Faction = "Noobs",
    Cost = { Gold = 120, Lumber = 40 },
    Health = 180, Damage = 22, Range = 2, Speed = 10, BuildTime = 6,
    ModelName = "NoobKnightModel",
}

UnitTypes.NoobBrute = {
    Name = "Noob Brute", Faction = "Noobs",
    Cost = { Gold = 200, Lumber = 100 },
    Health = 350, Damage = 35, Range = 2, Speed = 6, BuildTime = 10,
    ModelName = "NoobBruteModel",
}

-- ========== GUESTS ==========
UnitTypes.GuestRecruit = {
    Name = "Guest Recruit", Faction = "Guests",
    Cost = { Gold = 50, Lumber = 0 },
    Health = 90, Damage = 14, Range = 2, Speed = 9, BuildTime = 3,
    ModelName = "GuestRecruitModel",
}

UnitTypes.GuestHunter = {
    Name = "Guest Hunter", Faction = "Guests",
    Cost = { Gold = 80, Lumber = 30 },
    Health = 65, Damage = 22, Range = 14, Speed = 8, BuildTime = 4,
    ModelName = "GuestHunterModel",
}

UnitTypes.GuestWarden = {
    Name = "Guest Warden", Faction = "Guests",
    Cost = { Gold = 130, Lumber = 45 },
    Health = 200, Damage = 24, Range = 2, Speed = 9, BuildTime = 6,
    ModelName = "GuestWardenModel",
}

UnitTypes.GuestOverseer = {
    Name = "Guest Overseer", Faction = "Guests",
    Cost = { Gold = 220, Lumber = 120 },
    Health = 320, Damage = 40, Range = 3, Speed = 7, BuildTime = 10,
    ModelName = "GuestOverseerModel",
}

function UnitTypes.Get(name)
    return UnitTypes[name]
end

function UnitTypes.GetForFaction(factionName)
    local list = {}
    for key, data in pairs(UnitTypes) do
        if type(data) == "table" and data.Faction == factionName then
            list[key] = data
        end
    end
    return list
end

return UnitTypes