-- Factions.lua
local Factions = {}

Factions.Noobs = {
    Name = "Noobs",
    DisplayName = "NOOBS",
    Tagline = "Сила в простоте",
    Colors = {
        Primary   = Color3.fromRGB(255, 224,  96),  -- жёлтый
        Secondary = Color3.fromRGB(  0, 130, 220),  -- синий
        Accent    = Color3.fromRGB( 60, 180,  80),  -- зелёный
    },
    -- Палитра классического Noob (R6)
    CharacterPalette = {
        head    = Color3.fromRGB(255, 224,  96),
        torso   = Color3.fromRGB(  0, 130, 220),
        arm     = Color3.fromRGB(255, 224,  96),
        leg     = Color3.fromRGB( 60, 180,  80),
        accent  = nil,  -- без полоски
    },
    Units     = { "NoobRecruit", "NoobSlinger", "NoobKnight", "NoobBrute" },
    Buildings = { "NoobHut", "NoobBarracks", "NoobRange", "NoobTower", "NoobStable" },
}

Factions.Guests = {
    Name = "Guests",
    DisplayName = "GUESTS",
    Tagline = "Холод и дисциплина",
    Colors = {
        Primary   = Color3.fromRGB(240, 240, 240),  -- белый
        Secondary = Color3.fromRGB( 20,  20,  20),  -- чёрный
        Accent    = Color3.fromRGB(220,  30,  40),  -- красный
    },
    -- Палитра классического Guest (белое тело, тёмные ноги, красный акцент)
    CharacterPalette = {
        head    = Color3.fromRGB(240, 240, 240),
        torso   = Color3.fromRGB( 25,  25,  30),
        arm     = Color3.fromRGB(240, 240, 240),
        leg     = Color3.fromRGB( 20,  20,  20),
        accent  = Color3.fromRGB(220,  30,  40),  -- красная полоса на груди
    },
    Units     = { "GuestRecruit", "GuestHunter", "GuestWarden", "GuestOverseer" },
    Buildings = { "GuestCamp", "GuestBarracks", "GuestWatchtower", "GuestForge", "GuestStable" },
}

-- Итератор по фракциям
function Factions.Get(factionName)
    return Factions[factionName]
end

return Factions