-- GameConfig.lua
local GameConfig = {}

GameConfig.GameName = "Classic Warfare"
GameConfig.MaxPlayersPerMatch = 4          -- 2x2
GameConfig.RoomCodeLength = 6
GameConfig.MatchPlaceId = 0                -- замените на Place ID арены

-- Базовые ресурсы
GameConfig.StartingGold = 500
GameConfig.StartingLumber = 300

-- Ключи DataStore
GameConfig.RoomStoreName = "ClassicWarfare_Rooms"

return GameConfig