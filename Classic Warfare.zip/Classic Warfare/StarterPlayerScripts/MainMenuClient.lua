-- MainMenuClient.lua
local Players            = game:GetService("Players")
local ReplicatedStorage  = game:GetService("ReplicatedStorage")
local TweenService       = game:GetService("TweenService")

local player     = Players.LocalPlayer
local playerGui  = player:WaitForChild("PlayerGui")

local Factions    = require(ReplicatedStorage:WaitForChild("Factions"))
local remotes     = ReplicatedStorage:WaitForChild("Remotes")
local startMatch  = remotes:WaitForChild("StartMatch")
local createRoom  = remotes:WaitForChild("CreateRoom")
local joinRoom    = remotes:WaitForChild("JoinRoom")

local selectedFaction = "Noobs"

-- ============================================================
--  Утилиты
-- ============================================================
local function makeGradient(parent, colors, rotation)
    local g = Instance.new("UIGradient")
    g.Color = ColorSequence.new{
        ColorSequenceKeypoint.new(0, colors[1]),
        ColorSequenceKeypoint.new(0.5, colors[2]),
        ColorSequenceKeypoint.new(1, colors[3]),
    }
    g.Rotation = rotation or 90
    g.Parent = parent
    return g
end

local function darken(color, factor)
    return Color3.new(
        math.clamp(color.R * factor, 0, 1),
        math.clamp(color.G * factor, 0, 1),
        math.clamp(color.B * factor, 0, 1)
    )
end

-- ============================================================
--  Создание блочного R6-персонажа из Frame-ов
-- ============================================================
local function makeBlockyCharacter(parent, palette, scale, position, anchor, depthFactor)
    depthFactor = depthFactor or 1
    local head  = darken(palette.head,  depthFactor)
    local torso = darken(palette.torso, depthFactor)
    local arm   = darken(palette.arm,   depthFactor)
    local leg   = darken(palette.leg,   depthFactor)
    local accent = palette.accent and darken(palette.accent, depthFactor) or nil

    local charFrame = Instance.new("Frame")
    charFrame.Size = UDim2.new(0, scale * 4, 0, scale * 5)
    charFrame.Position = position
    charFrame.AnchorPoint = anchor
    charFrame.BackgroundTransparency = 1
    charFrame.Parent = parent

    local function part(name, sizePx, pos, color)
        local f = Instance.new("Frame")
        f.Name = name
        f.Size = UDim2.new(0, sizePx.X, 0, sizePx.Y)
        f.Position = pos
        f.BackgroundColor3 = color
        f.BorderSizePixel = 0
        f.Parent = charFrame

        local stroke = Instance.new("UIStroke")
        stroke.Color = Color3.fromRGB(0, 0, 0)
        stroke.Thickness = 1
        stroke.Transparency = 0.35
        stroke.Parent = f

        return f
    end

    -- Голова: 2×1, центр сверху
    part("Head", Vector2.new(scale*2, scale*1),
        UDim2.new(0.5, 0, 0, 0), head).AnchorPoint = Vector2.new(0.5, 0)

    -- Торс: 2×2
    part("Torso", Vector2.new(scale*2, scale*2),
        UDim2.new(0.5, 0, 0, scale*1), torso).AnchorPoint = Vector2.new(0.5, 0)

    -- Руки: 1×2
    part("LeftArm",  Vector2.new(scale, scale*2), UDim2.new(0.5, -scale*2, 0, scale*1), arm)
    part("RightArm", Vector2.new(scale, scale*2), UDim2.new(0.5,  scale,   0, scale*1), arm)

    -- Ноги: 1×2
    part("LeftLeg",  Vector2.new(scale, scale*2), UDim2.new(0.5, -scale, 0, scale*3), leg)
    part("RightLeg", Vector2.new(scale, scale*2), UDim2.new(0.5, 0,      0, scale*3), leg)

    -- Красная полоска на груди (для Гостей)
    if accent then
        local band = Instance.new("Frame")
        band.Size = UDim2.new(1, 0, 0, scale * 0.25)
        band.Position = UDim2.new(0, 0, 0, scale * 0.5)
        band.BackgroundColor3 = accent
        band.BorderSizePixel = 0
        band.ZIndex = 2
        band.Parent = charFrame:FindFirstChild("Torso")
    end

    return charFrame
end

-- ============================================================
--  UI
-- ============================================================
local screenGui = Instance.new("ScreenGui")
screenGui.Name = "MainMenu"
screenGui.ResetOnSpawn = false
screenGui.IgnoreGuiInset = true
screenGui.DisplayOrder = 10
screenGui.Parent = playerGui

-- ---------- Корневой фон ----------
local bg = Instance.new("Frame")
bg.Size = UDim2.fromScale(1, 1)
bg.BackgroundColor3 = Color3.fromRGB(10, 10, 14)
bg.BorderSizePixel = 0
bg.Parent = screenGui

-- ---------- ЛЕВАЯ половина: NOOBS ----------
local leftPanel = Instance.new("Frame")
leftPanel.Size = UDim2.fromScale(0.5, 1)
leftPanel.BackgroundColor3 = Factions.Noobs.Colors.Primary
leftPanel.BorderSizePixel = 0
leftPanel.Parent = bg

makeGradient(leftPanel, {
    Factions.Noobs.Colors.Primary,     -- жёлтый сверху
    Factions.Noobs.Colors.Accent,      -- зелёный в середине
    Factions.Noobs.Colors.Secondary,   -- синий снизу
}, 90)

-- Тёмная подложка у низа, чтобы фигурки «стояли на земле»
local leftShade = Instance.new("Frame")
leftShade.Size = UDim2.fromScale(1, 0.35)
leftShade.Position = UDim2.fromScale(0, 0.65)
leftShade.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
leftShade.BorderSizePixel = 0
leftShade.Parent = leftPanel

local leftShadeGradient = Instance.new("UIGradient")
leftShadeGradient.Rotation = 90
leftShadeGradient.Transparency = NumberSequence.new{
    NumberSequenceKeypoint.new(0, 1),
    NumberSequenceKeypoint.new(1, 0.55),
}
leftShadeGradient.Parent = leftShade

-- ---------- ПРАВАЯ половина: GUESTS ----------
local rightPanel = Instance.new("Frame")
rightPanel.Size = UDim2.fromScale(0.5, 1)
rightPanel.Position = UDim2.fromScale(0.5, 0)
rightPanel.BackgroundColor3 = Factions.Guests.Colors.Primary
rightPanel.BorderSizePixel = 0
rightPanel.Parent = bg

makeGradient(rightPanel, {
    Factions.Guests.Colors.Accent,      -- красный сверху
    Factions.Guests.Colors.Secondary,   -- чёрный в середине
    Factions.Guests.Colors.Primary,     -- белый снизу
}, 90)

local rightShade = Instance.new("Frame")
rightShade.Size = UDim2.fromScale(1, 0.35)
rightShade.Position = UDim2.fromScale(0, 0.65)
rightShade.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
rightShade.BorderSizePixel = 0
rightShade.Parent = rightPanel

local rightShadeGradient = Instance.new("UIGradient")
rightShadeGradient.Rotation = 90
rightShadeGradient.Transparency = NumberSequence.new{
    NumberSequenceKeypoint.new(0, 1),
    NumberSequenceKeypoint.new(1, 0.55),
}
rightShadeGradient.Parent = rightShade

-- ---------- Персонажи-силуэты ----------
-- NOOBS: два юнита на фоне
makeBlockyCharacter(leftPanel, Factions.Noobs.CharacterPalette,
    26, UDim2.new(0.10, 0, 0.97, 0), Vector2.new(0.5, 1), 0.55)   -- задний план

makeBlockyCharacter(leftPanel, Factions.Noobs.CharacterPalette,
    44, UDim2.new(0.27, 0, 1.00, 0), Vector2.new(0.5, 1), 1.0)    -- передний план

-- GUESTS: два юнита на фоне
makeBlockyCharacter(rightPanel, Factions.Guests.CharacterPalette,
    44, UDim2.new(0.73, 0, 1.00, 0), Vector2.new(0.5, 1), 1.0)

makeBlockyCharacter(rightPanel, Factions.Guests.CharacterPalette,
    26, UDim2.new(0.90, 0, 0.97, 0), Vector2.new(0.5, 1), 0.55)

-- ---------- Названия фракций на половинах ----------
local function makeFactionLabel(parent, faction, color, alignRight)
    local label = Instance.new("TextLabel")
    label.Size = UDim2.new(0.8, 0, 0, 90)
    label.Position = alignRight and UDim2.new(0.5, 0, 0, 60) or UDim2.new(0.5, 0, 0, 60)
    label.AnchorPoint = Vector2.new(0.5, 0)
    label.BackgroundTransparency = 1
    label.Text = faction.DisplayName
    label.TextColor3 = color
    label.TextScaled = true
    label.Font = Enum.Font.GothamBlack
    label.TextStrokeTransparency = 0.4
    label.TextStrokeColor3 = Color3.fromRGB(0, 0, 0)
    label.Parent = parent

    -- ============================================================
--  Создание эмблем фракций (чистый UI, без картинок)
-- ============================================================
local function createEmblem(parent, isNoob)
    local emblem = Instance.new("Frame")
    emblem.Size = UDim2.fromOffset(64, 64)
    -- Позиционируем над названием фракции
    emblem.Position = UDim2.new(0.5, -32, 0, -70) 
    emblem.BackgroundColor3 = isNoob and Color3.fromRGB(0, 130, 220) or Color3.fromRGB(20, 20, 20)
    emblem.BorderSizePixel = 0
    emblem.ZIndex = 5
    emblem.Parent = parent

    -- Закругление (делаем форму щита)
    local corner = Instance.new("UICorner")
    corner.CornerRadius = UDim.new(0, 12)
    corner.Parent = emblem

    -- Окантовка
    local stroke = Instance.new("UIStroke")
    stroke.Color = isNoob and Color3.fromRGB(255, 224, 96) or Color3.fromRGB(220, 30, 40)
    stroke.Thickness = 4
    stroke.Parent = emblem

    -- Внутренний фон
    local inner = Instance.new("Frame")
    inner.Size = UDim2.new(1, -12, 1, -12)
    inner.Position = UDim2.new(0.5, 0, 0.5, 0)
    inner.AnchorPoint = Vector2.new(0.5, 0.5)
    inner.BackgroundColor3 = isNoob and Color3.fromRGB(255, 224, 96) or Color3.fromRGB(240, 240, 240)
    inner.BorderSizePixel = 0
    inner.ZIndex = 6
    inner.Parent = emblem

    local innerCorner = Instance.new("UICorner")
    innerCorner.CornerRadius = UDim.new(0, 8)
    innerCorner.Parent = inner

    if isNoob then
        -- Эмблема Нуба: Улыбающееся лицо
        local leftEye = Instance.new("Frame")
        leftEye.Size = UDim2.fromOffset(8, 12)
        leftEye.Position = UDim2.new(0.3, 0, 0.4, 0)
        leftEye.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
        leftEye.ZIndex = 7
        leftEye.Parent = inner

        local rightEye = leftEye:Clone()
        rightEye.Position = UDim2.new(0.7, -8, 0.4, 0)
        rightEye.Parent = inner

        local smile = Instance.new("Frame")
        smile.Size = UDim2.fromOffset(24, 6)
        smile.Position = UDim2.new(0.5, -12, 0.7, 0)
        smile.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
        smile.ZIndex = 7
        smile.Parent = inner

        local smileCorner = Instance.new("UICorner")
        smileCorner.CornerRadius = UDim.new(1, 0) -- Сильное закругление для улыбки
        smileCorner.Parent = smile
    else
        -- Эмблема Гостя: Череп
        local skull = Instance.new("Frame")
        skull.Size = UDim2.new(0.7, 0, 0.6, 0)
        skull.Position = UDim2.new(0.5, 0, 0.45, 0)
        skull.AnchorPoint = Vector2.new(0.5, 0.5)
        skull.BackgroundColor3 = Color3.fromRGB(20, 20, 20)
        skull.ZIndex = 7
        skull.Parent = inner
        
        local skullCorner = Instance.new("UICorner")
        skullCorner.CornerRadius = UDim.new(0, 10)
        skullCorner.Parent = skull

        -- Глаза черепа (красные)
        local leftSocket = Instance.new("Frame")
        leftSocket.Size = UDim2.new(0.3, 0, 0.3, 0)
        leftSocket.Position = UDim2.new(0.15, 0, 0.2, 0)
        leftSocket.BackgroundColor3 = Color3.fromRGB(220, 30, 40)
        leftSocket.ZIndex = 8
        leftSocket.Parent = skull
        
        local rightSocket = leftSocket:Clone()
        rightSocket.Position = UDim2.new(0.55, 0, 0.2, 0)
        rightSocket.Parent = skull

        -- Челюсть
        local jaw = Instance.new("Frame")
        jaw.Size = UDim2.new(0.6, 0, 0.15, 0)
        jaw.Position = UDim2.new(0.5, 0, 0.7, 0)
        jaw.AnchorPoint = Vector2.new(0.5, 0.5)
        jaw.BackgroundColor3 = Color3.fromRGB(240, 240, 240)
        jaw.ZIndex = 8
        jaw.Parent = skull
    end
end

-- Добавляем эмблемы на панели
createEmblem(leftPanel, true)
createEmblem(rightPanel, false)

    local tagline = Instance.new("TextLabel")
    tagline.Size = UDim2.new(0.8, 0, 0, 30)
    tagline.Position = UDim2.new(0.5, 0, 0, 150)
    tagline.AnchorPoint = Vector2.new(0.5, 0)
    tagline.BackgroundTransparency = 1
    tagline.Text = faction.Tagline
    tagline.TextColor3 = color
    tagline.TextTransparency = 0.2
    tagline.TextScaled = true
    tagline.Font = Enum.Font.Gotham
    tagline.Parent = parent
end

makeFactionLabel(leftPanel,  Factions.Noobs,  Color3.fromRGB(255, 255, 255))
makeFactionLabel(rightPanel, Factions.Guests, Color3.fromRGB(255, 255, 255))

-- ---------- Центральное меню ----------
local menu = Instance.new("Frame")
menu.Size = UDim2.new(0, 460, 0, 500)
menu.Position = UDim2.new(0.5, 0, 0.5, 0)
menu.AnchorPoint = Vector2.new(0.5, 0.5)
menu.BackgroundColor3 = Color3.fromRGB(18, 18, 24)
menu.BackgroundTransparency = 0.08
menu.BorderSizePixel = 0
menu.ZIndex = 5
menu.Parent = bg

local menuCorner = Instance.new("UICorner")
menuCorner.CornerRadius = UDim.new(0, 14)
menuCorner.Parent = menu

local menuStroke = Instance.new("UIStroke")
menuStroke.Color = Color3.fromRGB(120, 120, 140)
menuStroke.Thickness = 2
menuStroke.Transparency = 0.3
menuStroke.Parent = menu

-- Заголовок
local title = Instance.new("TextLabel")
title.Size = UDim2.new(1, -40, 0, 50)
title.Position = UDim2.new(0, 20, 0, 20)
title.BackgroundTransparency = 1
title.Text = "CLASSIC WARFARE"
title.TextColor3 = Color3.fromRGB(255, 200, 80)
title.TextScaled = true
title.Font = Enum.Font.GothamBlack
title.ZIndex = 6
title.Parent = menu

local subtitle = Instance.new("TextLabel")
subtitle.Size = UDim2.new(1, -40, 0, 18)
subtitle.Position = UDim2.new(0, 20, 0, 70)
subtitle.BackgroundTransparency = 1
subtitle.Text = "ВЫБЕРИТЕ ФРАКЦИЮ"
subtitle.TextColor3 = Color3.fromRGB(180, 180, 200)
subtitle.TextScaled = true
subtitle.Font = Enum.Font.GothamBold
subtitle.ZIndex = 6
subtitle.Parent = menu

-- ---------- Селектор фракций ----------
local noobBtn = Instance.new("TextButton")
noobBtn.Size = UDim2.new(0.44, 0, 0, 56)
noobBtn.Position = UDim2.new(0.04, 0, 0, 96)
noobBtn.BackgroundColor3 = Factions.Noobs.Colors.Primary
noobBtn.Text = "NOOBS"
noobBtn.TextColor3 = Factions.Noobs.Colors.Secondary
noobBtn.TextScaled = true
noobBtn.Font = Enum.Font.GothamBlack
noobBtn.AutoButtonColor = false
noobBtn.ZIndex = 6
noobBtn.Parent = menu

local noobCorner = Instance.new("UICorner")
noobCorner.CornerRadius = UDim.new(0, 10)
noobCorner.Parent = noobBtn

local noobStroke = Instance.new("UIStroke")
noobStroke.Color = Color3.fromRGB(255, 255, 255)
noobStroke.Thickness = 3
noobStroke.Parent = noobBtn

local guestBtn = Instance.new("TextButton")
guestBtn.Size = UDim2.new(0.44, 0, 0, 56)
guestBtn.Position = UDim2.new(0.52, 0, 0, 96)
guestBtn.BackgroundColor3 = Factions.Guests.Colors.Secondary
guestBtn.Text = "GUESTS"
guestBtn.TextColor3 = Factions.Guests.Colors.Primary
guestBtn.TextScaled = true
guestBtn.Font = Enum.Font.GothamBlack
guestBtn.AutoButtonColor = false
guestBtn.ZIndex = 6
guestBtn.Parent = menu

local guestCorner = Instance.new("UICorner")
guestCorner.CornerRadius = UDim.new(0, 10)
guestCorner.Parent = guestBtn

local guestStroke = Instance.new("UIStroke")
guestStroke.Color = Factions.Guests.Colors.Accent
guestStroke.Thickness = 3
guestStroke.Transparency = 0.7
guestStroke.Parent = guestBtn

-- Обновление визуального состояния кнопок
local function refreshFactionSelection()
    if selectedFaction == "Noobs" then
        noobStroke.Transparency  = 0
        guestStroke.Transparency = 0.7
    else
        noobStroke.Transparency  = 0.7
        guestStroke.Transparency = 0
    end
end
refreshFactionSelection()

noobBtn.MouseButton1Click:Connect(function()
    selectedFaction = "Noobs"
    refreshFactionSelection()
end)

guestBtn.MouseButton1Click:Connect(function()
    selectedFaction = "Guests"
    refreshFactionSelection()
end)

-- ---------- Кнопки действий ----------
local function makeMenuButton(text, yPos, color)
    local btn = Instance.new("TextButton")
    btn.Size = UDim2.new(1, -40, 0, 48)
    btn.Position = UDim2.new(0, 20, 0, yPos)
    btn.BackgroundColor3 = color
    btn.Text = text
    btn.TextColor3 = Color3.fromRGB(255, 255, 255)
    btn.TextScaled = true
    btn.Font = Enum.Font.GothamBold
    btn.ZIndex = 6
    btn.Parent = menu

    local corner = Instance.new("UICorner")
    corner.CornerRadius = UDim.new(0, 8)
    corner.Parent = btn

    return btn
end

local quickMatch  = makeMenuButton("Быстрый матч",    176, Color3.fromRGB(70, 130, 200))
local createRoom  = makeMenuButton("Создать комнату", 236, Color3.fromRGB( 80, 160, 100))

-- ---------- Поле для кода ----------
local codeRowY = 304
local codeBox = Instance.new("TextBox")
codeBox.Size = UDim2.new(1, -150, 0, 44)
codeBox.Position = UDim2.new(0, 20, 0, codeRowY)
codeBox.BackgroundColor3 = Color3.fromRGB(40, 40, 52)
codeBox.Text = ""
codeBox.PlaceholderText = "Код комнаты"
codeBox.PlaceholderColor3 = Color3.fromRGB(140, 140, 160)
codeBox.TextColor3 = Color3.fromRGB(240, 240, 240)
codeBox.TextScaled = true
codeBox.Font = Enum.Font.Gotham
codeBox.ZIndex = 6
codeBox.Parent = menu

local codeCorner = Instance.new("UICorner")
codeCorner.CornerRadius = UDim.new(0, 8)
codeCorner.Parent = codeBox

local joinBtn = Instance.new("TextButton")
joinBtn.Size = UDim2.new(0, 110, 0, 44)
joinBtn.Position = UDim2.new(1, -130, 0, codeRowY)
joinBtn.BackgroundColor3 = Color3.fromRGB(180, 120, 60)
joinBtn.Text = "Войти"
joinBtn.TextColor3 = Color3.fromRGB(255, 255, 255)
joinBtn.TextScaled = true
joinBtn.Font = Enum.Font.GothamBold
joinBtn.ZIndex = 6
joinBtn.Parent = menu

local joinCorner = Instance.new("UICorner")
joinCorner.CornerRadius = UDim.new(0, 8)
joinCorner.Parent = joinBtn

-- ---------- Статус-подпись ----------
local statusLabel = Instance.new("TextLabel")
statusLabel.Size = UDim2.new(1, -40, 0, 24)
statusLabel.Position = UDim2.new(0, 20, 1, -44)
statusLabel.AnchorPoint = Vector2.new(0, 0)
statusLabel.BackgroundTransparency = 1
statusLabel.Text = ""
statusLabel.TextColor3 = Color3.fromRGB(200, 200, 220)
statusLabel.TextScaled = true
statusLabel.Font = Enum.Font.Gotham
statusLabel.ZIndex = 6
statusLabel.Parent = menu

local function setStatus(text)
    statusLabel.Text = text
end

-- ============================================================
--  Обработчики
-- ============================================================
quickMatch.MouseButton1Click:Connect(function()
    if not quickMatch.Active then return end
    quickMatch.Active = false
    quickMatch.Text = "Поиск соперников..."
    setStatus("Выбрана фракция: " .. selectedFaction)
    startMatch:FireServer(selectedFaction)
end)

createRoom.MouseButton1Click:Connect(function()
    setStatus("Создание комнаты...")
    createRoom:FireServer(selectedFaction)
end)

joinBtn.MouseButton1Click:Connect(function()
    local code = string.upper(string.gsub(codeBox.Text, "%s", ""))
    if #code >= 4 then
        setStatus("Подключение к комнате " .. code .. "...")
        joinRoom:FireServer(code)
    else
        setStatus("Введите код комнаты (4+ символа)")
    end
end)

-- ============================================================
--  Лёгкая анимация «дыхания» фоновых фигур
-- ============================================================
task.spawn(function()
    local t = 0
    while screenGui.Parent do
        t += task.wait(0.05)
        -- Слегка покачиваем прозрачность полос-теней
        local shift = (math.sin(t * 1.2) + 1) * 0.02
        leftShadeGradient.Transparency = NumberSequence.new{
            NumberSequenceKeypoint.new(0, 1),
            NumberSequenceKeypoint.new(1, 0.55 - shift),
        }
        rightShadeGradient.Transparency = NumberSequence.new{
            NumberSequenceKeypoint.new(0, 1),
            NumberSequenceKeypoint.new(1, 0.55 - shift),
        }
    end
end)

-- ============================================================
--  Анимация марша юнитов (Вторжение)
-- ============================================================
local TweenService = game:GetService("TweenService")
local isInvading = false

local function playInvasion(factionName)
    if isInvading then return end
    isInvading = true

    local panel = (factionName == "Noobs") and leftPanel or rightPanel
    local palette = (factionName == "Noobs") and Factions.Noobs.CharacterPalette or Factions.Guests.CharacterPalette
    local isLeft = (factionName == "Noobs")

    -- Создаем 3 юнита, которые будут выбегать
    for i = 1, 3 do
        task.spawn(function()
            -- Задержка для эффекта "волны"
            task.wait(i * 0.15)

            -- Создаем юнита за пределами экрана
            local startX = isLeft and -0.3 or 1.3
            local targetX = isLeft and (0.4 + (i * 0.1)) or (0.6 - (i * 0.1))
            
            local soldier = makeBlockyCharacter(
                panel, 
                palette, 
                18 + (i * 2), -- Разный размер для перспективы
                UDim2.new(startX, 0, 0.85, 0), 
                Vector2.new(0.5, 1), 
                0.8
            )
            soldier.ZIndex = 4

            -- Анимация выбегания
            local moveTween = TweenService:Create(
                soldier,
                TweenInfo.new(1.5, Enum.EasingStyle.Quad, Enum.EasingDirection.Out),
                { Position = UDim2.new(targetX, 0, 0.85, 0) }
            )
            
            -- Анимация покачивания при ходьбе
            local bobTween = TweenService:Create(
                soldier,
                TweenInfo.new(0.2, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut, -1, true),
                { Position = UDim2.new(targetX, 0, 0.85, -10) } -- Подпрыгивание
            )

            moveTween:Play()
            
            -- Начинаем покачиваться только когда добежали
            moveTween.Completed:Connect(function()
                bobTween:Play()
            end)

            -- Удаляем юнита через 3 секунды, чтобы не засорять память
            task.delay(3.5, function()
                if soldier then
                    local fadeTween = TweenService:Create(soldier, TweenInfo.new(0.5), { BackgroundTransparency = 1 })
                    -- Если это модель, нужно скрывать все дочерние элементы (упрощенно)
                    for _, child in ipairs(soldier:GetDescendants()) do
                        if child:IsA("Frame") then
                            TweenService:Create(child, TweenInfo.new(0.5), { BackgroundTransparency = 1 }):Play()
                        end
                    end
                    task.wait(0.5)
                    soldier:Destroy()
                end
            end)
        end)
    end

    -- Блокируем спам анимацией на 3 секунды
    task.delay(3, function()
        isInvading = false
    end)
end

-- Привязываем анимацию к кнопкам выбора фракции
noobBtn.MouseButton1Click:Connect(function()
    selectedFaction = "Noobs"
    refreshFactionSelection()
    playInvasion("Noobs")
end)

guestBtn.MouseButton1Click:Connect(function()
    selectedFaction = "Guests"
    refreshFactionSelection()
    playInvasion("Guests")
end)