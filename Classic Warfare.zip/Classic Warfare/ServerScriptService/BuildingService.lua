-- BuildingService.lua (Script)
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Players = game:GetService("Players")

local BuildingTypes = require(ReplicatedStorage:WaitForChild("BuildingTypes"))
local GameConfig = require(ReplicatedStorage:WaitForChild("GameConfig"))

local remotes = ReplicatedStorage:WaitForChild("Remotes")
local placeBuilding = remotes:WaitForChild("PlaceBuilding")

-- Простейший учёт ресурсов в памяти (для старта; позже заменить на DataStore/профиль)
local playerResources = {}

Players.PlayerAdded:Connect(function(player)
    playerResources[player] = {
        Gold = GameConfig.StartingGold,
        Lumber = GameConfig.StartingLumber,
    }
end)

Players.PlayerRemoving:Connect(function(player)
    playerResources[player] = nil
end)

local function canAfford(player, cost)
    local res = playerResources[player]
    if not res then return false end
    for resource, amount in pairs(cost) do
        if (res[resource] or 0) < amount then
            return false
        end
    end
    return true
end

local function pay(player, cost)
    local res = playerResources[player]
    for resource, amount in pairs(cost) do
        res[resource] -= amount
    end
end

placeBuilding.OnServerEvent:Connect(function(player, buildingName, position)
    local data = BuildingTypes.Get(buildingName)
    if not data then return end

    if typeof(position) ~= "Vector3" then return end

    -- Проверка дистанции от персонажа (защита от размещения на другом конце карты)
    local character = player.Character
    if not character then return end
    local root = character:FindFirstChild("HumanoidRootPart")
    if not root then return end

    if (root.Position - position).Magnitude > 30 then
        return
    end

    if not canAfford(player, data.Cost) then
        return
    end

    pay(player, data.Cost)

    -- Создание простого плейсхолдера постройки
    local part = Instance.new("Part")
    part.Name = buildingName
    part.Size = data.Size
    part.Position = position
    part.Anchored = true
    part.Color = Color3.fromRGB(120, 120, 140)
    part.Parent = workspace

    -- В реальной игре здесь нужно подгружать Model по data.ModelName
end)