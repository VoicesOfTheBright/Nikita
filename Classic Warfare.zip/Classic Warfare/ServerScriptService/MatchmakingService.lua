-- MatchmakingService.lua (Script)
local TeleportService = game:GetService("TeleportService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local GameConfig = require(ReplicatedStorage:WaitForChild("GameConfig"))
local remotes = ReplicatedStorage:WaitForChild("Remotes")
local startMatch = remotes:WaitForChild("StartMatch")

local queue = {}
local teleporting = false

local function tryStartMatch()
    if teleporting then return end
    if #queue < GameConfig.MaxPlayersPerMatch then return end

    teleporting = true

    -- Забираем первых N игроков
    local batch = {}
    for i = 1, GameConfig.MaxPlayersPerMatch do
        table.insert(batch, queue[i])
    end
    -- Очищаем очередь от этих игроков
    for i = GameConfig.MaxPlayersPerMatch, 1, -1 do
        table.remove(queue, i)
    end

    -- Резервируем изолированный сервер под матч
    local ok, accessCode = pcall(function()
        return select(1, TeleportService:ReserveServerAsync(GameConfig.MatchPlaceId))
    end)

    if not ok or typeof(accessCode) ~= "string" then
        teleporting = false
        return
    end

    local options = Instance.new("TeleportOptions")
    options.ReservedServerAccessCode = accessCode
    options:SetTeleportData({
        matchStartedAt = os.time(),
        isMatch = true,
    })

    pcall(function()
        TeleportService:TeleportAsync(GameConfig.MatchPlaceId, batch, options)
    end)

    teleporting = false
end

-- MatchmakingService.lua — ключевые изменения
startMatch.OnServerEvent:Connect(function(player, factionName)
    if factionName ~= "Noobs" and factionName ~= "Guests" then
        factionName = "Noobs"   -- fallback
    end
    -- ставим игрока в очередь вместе с выбранной фракцией
    table.insert(queue, { player = player, faction = factionName })
    tryStartMatch()
end)

Players.PlayerRemoving:Connect(function(player)
    for i = #queue, 1, -1 do
        if queue[i] == player then
            table.remove(queue, i)
        end
    end
end)