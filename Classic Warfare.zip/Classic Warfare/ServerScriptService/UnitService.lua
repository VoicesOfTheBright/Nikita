-- UnitService.lua (Script)
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")

local UnitTypes = require(ReplicatedStorage:WaitForChild("UnitTypes"))

local units = {} -- {model = Model, owner = Player, data = table, target = Model?}

local function createUnitModel(unitData, position, owner)
    local model = Instance.new("Model")
    model.Name = unitData.Name

    local torso = Instance.new("Part")
    torso.Name = "Torso"
    torso.Size = Vector3.new(2, 2, 1)
    torso.Position = position
    torso.Anchored = false
    torso.CanCollide = true
    torso.Color = (owner.Team and owner.Team.TeamColor.Color) or Color3.fromRGB(200, 60, 60)
    torso.Parent = model

    local humanoid = Instance.new("Humanoid")
    humanoid.MaxHealth = unitData.Health
    humanoid.Health = unitData.Health
    humanoid.Parent = model

    model.PrimaryPart = torso
    model.Parent = workspace

    return model
end

local function spawnUnit(unitName, position, owner)
    local data = UnitTypes.Get(unitName)
    if not data then return end

    local model = createUnitModel(data, position, owner)

    table.insert(units, {
        model = model,
        owner = owner,
        data = data,
        lastAttack = 0,
    })
end

-- Простой цикл боя
RunService.Heartbeat:Connect(function(dt)
    local now = os.clock()

    for _, unit in ipairs(units) do
        if not unit.model.Parent then continue end
        local humanoid = unit.model:FindFirstChildOfClass("Humanoid")
        if not humanoid or humanoid.Health <= 0 then continue end

        -- Ищем ближайшего врага (упрощённо: любого юнита другого владельца)
        local myPos = unit.model.PrimaryPart.Position
        local bestTarget, bestDist = nil, unit.data.Range

        for _, other in ipairs(units) do
            if other.owner ~= unit.owner and other.model.Parent then
                local otherHum = other.model:FindFirstChildOfClass("Humanoid")
                if otherHum and otherHum.Health > 0 then
                    local dist = (other.model.PrimaryPart.Position - myPos).Magnitude
                    if dist < bestDist then
                        bestDist = dist
                        bestTarget = other
                    end
                end
            end
        end

        if bestTarget and now - unit.lastAttack > 1 then
            unit.lastAttack = now
            local targetHum = bestTarget.model:FindFirstChildOfClass("Humanoid")
            if targetHum then
                targetHum:TakeDamage(unit.data.Damage)
            end
        end
    end

    -- Удаляем мёртвых
    for i = #units, 1, -1 do
        local unit = units[i]
        if not unit.model.Parent then
            table.remove(units, i)
        else
            local hum = unit.model:FindFirstChildOfClass("Humanoid")
            if hum and hum.Health <= 0 then
                unit.model:Destroy()
                table.remove(units, i)
            end
        end
    end
end)