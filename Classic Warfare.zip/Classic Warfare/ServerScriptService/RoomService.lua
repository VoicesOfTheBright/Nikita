-- RoomService.lua (Script)
local DataStoreService = game:GetService("DataStoreService")
local TeleportService = game:GetService("TeleportService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Players = game:GetService("Players")

local GameConfig = require(ReplicatedStorage:WaitForChild("GameConfig"))
local remotes = ReplicatedStorage:WaitForChild("Remotes")
local createRoom = remotes:WaitForChild("CreateRoom")
local joinRoom = remotes:WaitForChild("JoinRoom")

local roomStore = DataStoreService:GetDataStore(GameConfig.RoomStoreName)

local function generateCode(): string
    local chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
    local code = ""
    for i = 1, GameConfig.RoomCodeLength do
        local idx = math.random(1, #chars)
        code ..= string.sub(chars, idx, idx)
    end
    return code
end

-- RoomService.lua — ключевые изменения
createRoom.OnServerEvent:Connect(function(player, factionName)
    factionName = (factionName == "Guests") and "Guests" or "Noobs"

    local code = generateCode()
    -- ... ReserveServerAsync как раньше ...
    local record = {
        hostUserId  = player.UserId,
        hostFaction = factionName,   -- ← новое поле
        accessCode  = accessCode,
        createdAt   = os.time(),
        expiresAt   = os.time() + 3600,
    }
    local code = generateCode()

    local ok, accessCode = pcall(function()
        return select(1, TeleportService:ReserveServerAsync(GameConfig.MatchPlaceId))
    end)

    if not ok or typeof(accessCode) ~= "string" then
        return
    end

    local record = {
        hostUserId = player.UserId,
        accessCode = accessCode,
        createdAt = os.time(),
        expiresAt = os.time() + 3600, -- 1 час
    }

    local saveOk = pcall(function()
        roomStore:SetAsync("room_" .. code, record)
    end)

    if not saveOk then return end

    -- Хост сразу телепортируется в свою комнату
    local options = Instance.new("TeleportOptions")
    options.ReservedServerAccessCode = accessCode
    options:SetTeleportData({ roomCode = code, isHost = true })

    pcall(function()
        TeleportService:TeleportAsync(GameConfig.MatchPlaceId, { player }, options)
    end)
end)

joinRoom.OnServerEvent:Connect(function(player, code)
    if typeof(code) ~= "string" or #code < 4 then return end

    local record
    local ok = pcall(function()
        record = roomStore:GetAsync("room_" .. code)
    end)

    if not ok or not record then
        return
    end

    if record.expiresAt < os.time() then
        return
    end

    local options = Instance.new("TeleportOptions")
    options.ReservedServerAccessCode = record.accessCode
    options:SetTeleportData({ roomCode = code })

    pcall(function()
        TeleportService:TeleportAsync(GameConfig.MatchPlaceId, { player }, options)
    end)
end)